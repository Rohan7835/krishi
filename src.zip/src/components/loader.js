import React, { useState, useEffect } from "react";
function Loader(props){    
return (
    <>
 <div className="loading">Loading...</div>
    </>
)
}
export default Loader;