import url from "./main_url";
// export const imageUrl = "https://api.krishicress.com/upload/"; //
export const imageUrl = url + "upload/"; //
