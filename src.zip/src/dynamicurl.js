import url from "./main_url";

// export const DynamicUrl = "https://api.krishicress.com/api";
export const DynamicUrl = url + "api"; // server
