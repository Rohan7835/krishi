import React from 'react';

const About = () => {
    return (
        <div className="jumbotron">
            <h1 className="display-3">About Me</h1>
        </div>
    );
}

export default About;