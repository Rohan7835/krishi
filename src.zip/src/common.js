import url from "./main_url";
// export const DynamicUrl = "https://api.krishicress.com/";
export const DynamicUrl = url;
