const DynamicUrl = "https://kc.storehey.com:3003/";
// const DynamicUrl = "https://api.krishicress.com/";
// const DynamicUrl = "http://localhost:3003/";

export default DynamicUrl;
